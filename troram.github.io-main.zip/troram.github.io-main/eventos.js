
[
    {
        "title": "Lituania vs. Gibraltar",
        "league": "Eliminatorias Eurocopa",
        "img": "37B3522BC5C3405AAFFD6714F02B9FA6626BC380B1D18FD272E0152A6A0DB319",
        "url": "/embed/eventos?r=aHR0cHM6Ly92aXBlcnBsYXloZC5jb20vc3Rhcmp3Lmh0bWw/Z2V0PWh0dHBzOi8vbGl2ZS1mdGMtbmEtc291dGgtMi5tZWRpYS5zdGFyb3R0LmNvbS9jbHQyL3ZhMDEvc3RhcnBsdXMvZXZlbnQvMjAyNC8wMy8yNi9MaXR1YW5pYV92c19HaWJyYWx0YXJfMjAyNDAzMjZfMTcxMTQ2NjQwODAzMC9jdHItYWxsLWNvbXBsZXRlLm0zdTgmaW1nPWh0dHBzOi8vcHJvZC1yaXBjdXQtZGVsaXZlcnkuZGlzbmV5LXBsdXMubmV0L3YxL3ZhcmlhbnQvc3Rhci8zN0IzNTIyQkM1QzM0MDVBQUZGRDY3MTRGMDJCOUZBNjYyNkJDMzgwQjFEMThGRDI3MkUwMTUyQTZBMERCMzE5L3NjYWxlP3dpZHRoPTE5MjAmYXNwZWN0UmF0aW89MS43OCZmb3JtYXQ9anBlZyZrZXk9ODIwMjYzMTQxOGRmNDhjYThmZjRhYzIzOGEyMGI5NTkma2V5Mj01OGU5OGUxNGQ4Y2UyYjczOThkZmIwNzI2OTA4OTA3NQ==",
        "status": "EN VIVO"
    },
    {
        "title": "Georgia vs. Grecia",
        "league": "Eliminatorias Eurocopa",
        "img": "5B4D07A761B255950C8EE15066F750B2003432EF73322DE9B3A196FAB35D0FE7",
        "url": "/embed/eventos?r=aHR0cHM6Ly92aXBlcnBsYXloZC5jb20vc3Rhcmp3Lmh0bWw/Z2V0PWh0dHBzOi8vbGl2ZS1mdGMtbmEtc291dGgtMi5tZWRpYS5zdGFyb3R0LmNvbS9ncnUxL3FiMDEvc3RhcnBsdXMvZXZlbnQvMjAyNC8wMy8yNi9HZW9yZ2lhX3ZzX0dyZWNpYV9QbGF5b2ZmXzIwMjQwMzI2XzE3MTE0NjY0MzcwMjUvY3RyLWFsbC1jb21wbGV0ZS5tM3U4JmltZz1odHRwczovL3Byb2QtcmlwY3V0LWRlbGl2ZXJ5LmRpc25leS1wbHVzLm5ldC92MS92YXJpYW50L3N0YXIvNUI0RDA3QTc2MUIyNTU5NTBDOEVFMTUwNjZGNzUwQjIwMDM0MzJFRjczMzIyREU5QjNBMTk2RkFCMzVEMEZFNy9zY2FsZT93aWR0aD0xOTIwJmFzcGVjdFJhdGlvPTEuNzgmZm9ybWF0PWpwZWcma2V5PTgxZDRiZGQ1ZTk3NjRjMDdhMGE0NTgzOWMxN2QwY2FmJmtleTI9NDVhZTk4Njk0MjZlZjI2ZjQ0YjlhNDJlNjEzNTdiM2Q=",
        "status": "EN VIVO"
    },
    {
        "title": "Letonia vs. Liechtenstein",
        "league": "Amistoso internacional",
        "img": "E464433271E5278D84B0F559B1B93395EA3575178DD8993FDF9D3BF47DBEBBD4",
        "url": "/embed/eventos?r=aHR0cHM6Ly92aXBlcnBsYXloZC5jb20vc3Rhcmp3Lmh0bWw/Z2V0PWh0dHBzOi8vbGl2ZS1mdGMtbmEtc291dGgtMi5tZWRpYS5zdGFyb3R0LmNvbS9jbHQyL3ZhMDEvc3RhcnBsdXMvZXZlbnQvMjAyNC8wMy8yNi9MYXR2aWFfdnNfTGllY2h0ZW5zdGVpbl8yMDI0MDMyNl8xNzExNDY2NDM5MDMzL2N0ci1hbGwtY29tcGxldGUubTN1OCZpbWc9aHR0cHM6Ly9wcm9kLXJpcGN1dC1kZWxpdmVyeS5kaXNuZXktcGx1cy5uZXQvdjEvdmFyaWFudC9zdGFyL0U0NjQ0MzMyNzFFNTI3OEQ4NEIwRjU1OUIxQjkzMzk1RUEzNTc1MTc4REQ4OTkzRkRGOUQzQkY0N0RCRUJCRDQvc2NhbGU/d2lkdGg9MTkyMCZhc3BlY3RSYXRpbz0xLjc4JmZvcm1hdD1qcGVnJmtleT1kYjgyMTlhODJkMmE0ZmNlODc4MTBjNGVlMWJjOTY0YSZrZXkyPWMwOWYzM2NlOGU4YWViZjI0YmY1NjBmNmE2MjMzYzlh",
        "status": "EN VIVO"
    },
    {
        "title": "Finlandia vs. Estonia",
        "league": "Amistoso internacional",
        "img": "7F82B236F5619A86F88758CEF81FD5DA4E451F1CB18B578880CE8964FCC0CA26",
        "url": "/embed/eventos?r=aHR0cHM6Ly92aXBlcnBsYXloZC5jb20vc3Rhcmp3Lmh0bWw/Z2V0PWh0dHBzOi8vbGl2ZS1mdGMtbmEtc291dGgtMi5tZWRpYS5zdGFyb3R0LmNvbS9jbHQyL3ZhMDEvc3RhcnBsdXMvZXZlbnQvMjAyNC8wMy8yNi9GaW5sYW5kaWFfdnNfRXN0b25pYV8yMDI0MDMyNl8xNzExNDY2NDE5MDMyL2N0ci1hbGwtY29tcGxldGUubTN1OCZpbWc9aHR0cHM6Ly9wcm9kLXJpcGN1dC1kZWxpdmVyeS5kaXNuZXktcGx1cy5uZXQvdjEvdmFyaWFudC9zdGFyLzdGODJCMjM2RjU2MTlBODZGODg3NThDRUY4MUZENURBNEU0NTFGMUNCMThCNTc4ODgwQ0U4OTY0RkNDMENBMjYvc2NhbGU/d2lkdGg9MTkyMCZhc3BlY3RSYXRpbz0xLjc4JmZvcm1hdD1qcGVnJmtleT0wZWI5MTFiNjdiZDI0YzA4YjhlNWMxNjE2ZWUyYjkxMCZrZXkyPWI5OTNhMTM3NmE1ZmU0ZTQ3MmQwNDM2ZGI0NjJlNzE4",
        "status": "EN VIVO"
    },
    {
        "title": "Noruega vs. Eslovaquia",
        "league": "Amistoso internacional",
        "img": "34819ED01B679126D2CEB9A470EAE2C078438AE302E07E53D5FEFFA2BAA6F56B",
        "url": "#",
        "status": "19:50"
    },
    {
        "title": "Malta vs. Bielorrusia",
        "league": "Amistoso internacional",
        "img": "BB24AFB2BA9ADD612199C99EF3F99CEF1D5BD446486D0F38DE30B46DF5AF5AAC",
        "url": "#",
        "status": "19:50"
    },
    {
        "title": "Hungr\u00eda vs. Kosovo",
        "league": "Amistoso internacional",
        "img": "D49A6B5321D1A7EE5F023B2548B1793B00237AB24050A8AFB26EBC122F377778",
        "url": "#",
        "status": "19:50"
    },
    {
        "title": "Rep\u00fablica Checa vs. Armenia",
        "league": "Amistoso internacional",
        "img": "D8F6441E5BE4027473D63DB716DAB4043F42996E8AA5AC5EB08DE17A00DEB652",
        "url": "#",
        "status": "20:50"
    },
    {
        "title": "Dinamarca vs. Islas Feroe",
        "league": "Amistoso internacional",
        "img": "91B5B34D95C07D05AA840C2AFEEB5E3F21D936FAF9A4025BFFFD1C825B992CF1",
        "url": "#",
        "status": "21:05"
    },
    {
        "title": "Ucrania vs. Islandia",
        "league": "Eliminatorias Eurocopa",
        "img": "FCFEBDDE76C10855F67FB37CA7E1CDB6CAA36E64ACC98A78A6CC81A3DB3668EC",
        "url": "#",
        "status": "21:25"
    },
    {
        "title": "Gales vs. Polonia",
        "league": "Elminatorias Eurocopa",
        "img": "2CF30DD5174889ED97937E38128AE693AC09752F86B6C9C824F4D0C2BCB755F6",
        "url": "#",
        "status": "21:30"
    },
    {
        "title": "Inglaterra vs. B\u00e9lgica",
        "league": "Amistoso internacional",
        "img": "7E42A1AE72E6B99F59E997061B2CD18E7FDC34558931B4318E880FE2F4BA4442",
        "url": "#",
        "status": "21:30"
    },
    {
        "title": "Alemania vs. Pa\u00edses Bajos",
        "league": "Amistoso internacional",
        "img": "A0A7304D3248A49B9049BB604994DDACD5C19281CE56A1106C15AFBAB2EE955F",
        "url": "#",
        "status": "21:30"
    },
    {
        "title": "Escocia vs. Irlanda del Norte",
        "league": "Amistoso internacional",
        "img": "AEB9F5D52AF0EB56A3140A1EF63861E037218480F8042120C7D6A1DD30CDEAE6",
        "url": "#",
        "status": "21:35"
    },
    {
        "title": "Rep\u00fablica de Irlanda vs. Suiza",
        "league": "Amistoso internacional",
        "img": "D52FD833518013D7E6C9A0354EA61FC316D461A6509401D112F9FDA2960A2220",
        "url": "#",
        "status": "21:35"
    },
    {
        "title": "Eslovenia vs. Portugal",
        "league": "Amistoso internacional",
        "img": "7277EB416F5A599D86007DE35F063C5755AAB28B4382C91918B84547487EA13D",
        "url": "#",
        "status": "21:25"
    },
    {
        "title": "Austria vs. Turqu\u00eda",
        "league": "Amistoso internacional",
        "img": "D77118163FBCFD91A683203CECCE08D14D175EF67F18E72C146308BB3772F3CA",
        "url": "#",
        "status": "21:25"
    },
    {
        "title": "Luxembourg vs. Kazajst\u00e1n",
        "league": "Amistoso internacional",
        "img": "12B15799D65338F9A4B81FB00C1F5DE8DC6536B75FFBE25617A6E935B299BB72",
        "url": "#",
        "status": "21:45"
    },
    {
        "title": "Francia vs. Chile",
        "league": "Amistoso internacional",
        "img": "23AECCD16C64D086818A1DA84A47509F9A4F74E6CE4B85F071E7C12AF811D847",
        "url": "#",
        "status": "21:40"
    },
    {
        "title": "Espa\u00f1a vs. Brasil",
        "league": "Amistoso internacional",
        "img": "5489DC5F945485CFE4C3C20D63BCAB2D4B3D2158AEFBEF0FBD8C8C2A887A714A",
        "url": "#",
        "status": "21:40"
    },
    {
        "title": "Bucks vs. Lakers",
        "league": "NBA",
        "img": "1FA986D795C9DD6378DF540B57AE209A2959157C335669B2B17EDEEA0BD535DF",
        "url": "#",
        "status": "01:30"
    },
    {
        "title": "Kings vs. Mavericks",
        "league": "NBA",
        "img": "259F7559230B9F6A84FB12CB4DA11B28714159F602D8257E7EAEED9A49B88137",
        "url": "#",
        "status": "04:00"
    }
]
